package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class ElevenBCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix,fiveseven, fiveeight
            ,fivenine,fiveten,fiveeleven;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elevenb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        fiveone = (EditText) findViewById(R.id.fivePointbElevenFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointbElevenSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointbElevenThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointbElevenFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointbElevenFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointbElevenSixthcourse);
        fiveseven = (EditText) findViewById(R.id.fivePointbElevenSeventhcourse);
        fiveeight = (EditText) findViewById(R.id.fivePointbElevenEightcourse);
        fivenine = (EditText) findViewById(R.id.fivePointbElevenNinthcourse);
        fiveten = (EditText) findViewById(R.id.fivePointbElevenTencourse);
        fiveeleven = (EditText) findViewById(R.id.fivePointbElevenElevencourse);
        nameofText = (TextView) findViewById(R.id.fivenewelevennameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        fiveeight.setTypeface(normal);
        fivenine.setTypeface(normal);
        fiveten.setTypeface(normal);
        fiveeleven.setTypeface(normal);
        nameofText.setTypeface(bold);



        cclickme = (Button)findViewById(R.id.Fivenewelevencoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fiveone = (EditText) findViewById(R.id.fivePointbElevenFirstCourse);
                fivetwo = (EditText) findViewById(R.id.fivePointbElevenSecondCourse);
                fivethree = (EditText) findViewById(R.id.fivePointbElevenThirdCourse);
                fivefour = (EditText) findViewById(R.id.fivePointbElevenFourthCourse);
                fivefive = (EditText) findViewById(R.id.fivePointbElevenFifthCourse);
                fivesix = (EditText) findViewById(R.id.fivePointbElevenSixthcourse);
                fiveseven = (EditText) findViewById(R.id.fivePointbElevenSeventhcourse);
                fiveeight = (EditText) findViewById(R.id.fivePointbElevenEightcourse);
                fivenine = (EditText) findViewById(R.id.fivePointbElevenNinthcourse);
                fiveten = (EditText) findViewById(R.id.fivePointbElevenTencourse);
                fiveeleven = (EditText) findViewById(R.id.fivePointbElevenElevencourse);




                Intent intent2 = new Intent(ElevenBCoursesActivity.this, NextElevenBCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                intent2.putExtra("8", fiveeight.getText().toString());
                intent2.putExtra("9", fivenine.getText().toString());
                intent2.putExtra("10", fiveten.getText().toString());
                intent2.putExtra("11", fiveeleven.getText().toString());



                startActivity(intent2);


            }
        });




    }

}



