package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class EightBCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix,fiveseven, fiveeight;
    private TextView nameofText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eightb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fiveone = (EditText) findViewById(R.id.fivePointbeightFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointeightbSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointeightbThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointeightbFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointeightbFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointeightbSixthcourse);
        fiveseven = (EditText) findViewById(R.id.fivePointeightbSeventhcourse);
        fiveeight = (EditText) findViewById(R.id.fivePointeightbEightcourse);
        nameofText = (TextView) findViewById(R.id.fiveneweightnameOfCoursesText);


        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        fiveeight.setTypeface(normal);
        nameofText.setTypeface(bold);

        cclickme = (Button)findViewById(R.id.Fiveneweightcoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent2 = new Intent(EightBCoursesActivity.this, NextEightBCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                intent2.putExtra("8", fiveeight.getText().toString());

                startActivity(intent2);


            }
        });



    }



}







