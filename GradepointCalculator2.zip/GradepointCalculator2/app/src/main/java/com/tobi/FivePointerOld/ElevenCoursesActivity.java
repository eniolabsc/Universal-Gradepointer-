package com.tobi.FivePointerOld;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class ElevenCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix,fiveseven, fiveeight
            ,fivenine,fiveten,fiveeleven;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eleven_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fiveone = (EditText) findViewById(R.id.fivePointElevenFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointElevenSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointElevenThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointElevenFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointElevenFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointElevenSixthcourse);
        fiveseven = (EditText) findViewById(R.id.fivePointElevenSeventhcourse);
        fiveeight = (EditText) findViewById(R.id.fivePointElevenEightcourse);
        fivenine = (EditText) findViewById(R.id.fivePointElevenNinthcourse);
        fiveten = (EditText) findViewById(R.id.fivePointElevenTencourse);
        fiveeleven = (EditText) findViewById(R.id.fivePointElevenElevencourse);



        nameofText = (TextView) findViewById(R.id.fiveoldelevennameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        fiveeight.setTypeface(normal);
        fivenine.setTypeface(normal);
        fiveten.setTypeface(normal);
        fiveeleven.setTypeface(normal);
        nameofText.setTypeface(bold);


        cclickme = (Button)findViewById(R.id.Fiveoldelevencoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                Intent intent2 = new Intent(ElevenCoursesActivity.this, NextElevenCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                intent2.putExtra("8", fiveeight.getText().toString());
                intent2.putExtra("9", fivenine.getText().toString());
                intent2.putExtra("10", fiveten.getText().toString());
                intent2.putExtra("11", fiveeleven.getText().toString());



                startActivity(intent2);


            }
        });




    }

}



