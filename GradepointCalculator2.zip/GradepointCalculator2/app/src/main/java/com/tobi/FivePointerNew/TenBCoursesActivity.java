package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;


public class TenBCoursesActivity extends AppCompatActivity {
    Button clicked;
    EditText tenone, tentwo, tenthree, tenfour, tenfive, tensix, tenseven, teneight, tennine, tenten;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tenone = (EditText) findViewById(R.id.fivePointbtenFirstCourse);
        tentwo = (EditText) findViewById(R.id.fivePointbtenSecondCourse);
        tenthree = (EditText) findViewById(R.id.fivePointbtenThirdCourse);
        tenfour = (EditText) findViewById(R.id.fivePointbtenFourthCourse);
        tenfive = (EditText) findViewById(R.id.fivePointbtenFifthCourse);
        tensix = (EditText) findViewById(R.id.fivePointbtenSixthcourse);
        tenseven = (EditText) findViewById(R.id.fivePointbtenSeventhcourse);
        teneight = (EditText) findViewById(R.id.fivePointbtenEightcourse);
        tennine = (EditText) findViewById(R.id.fivePointbtenNinthcourse);
        tenten = (EditText) findViewById(R.id.fivePointbtenTencourse);


        nameofText = (TextView) findViewById(R.id.fivenewtennameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        tenone.setTypeface(normal);
        tentwo.setTypeface(normal);
        tenthree.setTypeface(normal);
        tenfour.setTypeface(normal);
        tenfive.setTypeface(normal);
        tensix.setTypeface(normal);
        tenseven.setTypeface(normal);
        teneight.setTypeface(normal);
        tennine.setTypeface(normal);
        tenten.setTypeface(normal);
        nameofText.setTypeface(bold);

        clicked = (Button) findViewById(R.id.Fivenewtencoursesbutton);
        clicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TenBCoursesActivity.this, NextTenBCoursesActivity.class);
                intent.putExtra("1", tenone.getText().toString());
                intent.putExtra("2", tentwo.getText().toString());
                intent.putExtra("3", tenthree.getText().toString());
                intent.putExtra("4", tenfour.getText().toString());
                intent.putExtra("5", tenfive.getText().toString());
                intent.putExtra("6", tensix.getText().toString());
                intent.putExtra("7", tenseven.getText().toString());
                intent.putExtra("8", teneight.getText().toString());
                intent.putExtra("9", tennine.getText().toString());
                intent.putExtra("10", tenten.getText().toString());
                startActivity(intent);

            }
        });







    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
