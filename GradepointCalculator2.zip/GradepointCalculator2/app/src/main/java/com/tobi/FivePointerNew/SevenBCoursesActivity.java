package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;


public class SevenBCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix,fiveseven;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sevenb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        fiveone = (EditText) findViewById(R.id.fivePointbsevenFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointbsevenSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointbsevenThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointbsevenFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointbsevenFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointbsevenSixthcourse);
        fiveseven = (EditText)findViewById(R.id.fivePointbsevenSeventhcourse);
        nameofText = (TextView) findViewById(R.id.fivenewsevennameOfCoursesText);




        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        nameofText.setTypeface(bold);


        cclickme = (Button)findViewById(R.id.Fivenewsevencoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fiveone = (EditText) findViewById(R.id.fivePointbsevenFirstCourse);
                fivetwo = (EditText) findViewById(R.id.fivePointbsevenSecondCourse);
                fivethree = (EditText) findViewById(R.id.fivePointbsevenThirdCourse);
                fivefour = (EditText) findViewById(R.id.fivePointbsevenFourthCourse);
                fivefive = (EditText) findViewById(R.id.fivePointbsevenFifthCourse);
                fivesix = (EditText) findViewById(R.id.fivePointbsevenSixthcourse);
                fiveseven = (EditText)findViewById(R.id.fivePointbsevenSeventhcourse);

                Intent intent2 = new Intent(SevenBCoursesActivity.this, NextSevenBCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                startActivity(intent2);




            }
        });


    }

}





