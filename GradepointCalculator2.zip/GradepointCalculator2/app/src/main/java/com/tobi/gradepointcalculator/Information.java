package com.tobi.gradepointcalculator;

/**
 * Created by USER on 10/30/2015.
 */
public class Information {

    int iconId;
    String title;
}
