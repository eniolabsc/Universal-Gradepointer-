package com.tobi.gradepointcalculator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.tobi.gradepointcalculator.TableData.TableInfo;

/**
 * Created by USER on 10/24/2015.
 */
public class DatabaseOperations extends SQLiteOpenHelper {
    public static final int database_version = 1;
    //command for creating database
    public String CREATE_QUERY = "CREATE TABLE " + TableInfo.TABLE_NAME + "(" + TableInfo.USER_NAME + " TEXT," + TableInfo.USER_PASS + " TEXT );";


    //Creating database on the method called databaseoperations involving the sqliteopenhelper constructor using the super keyword
    public DatabaseOperations(Context context) {
        super(context, TableInfo.DATABASE_NAME, null, database_version);
        //Database successfully created
        Log.d("Database Operations", "Database Created");
    }

    @Override
    public void onCreate(SQLiteDatabase sdb) {
        sdb.execSQL(CREATE_QUERY);
        Log.d("Database Operations", "Table Created");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

    //Method to insert data into Database
    public void putInformation(DatabaseOperations dop, String name, String pass) {
        //You need object of Sqlite to insert the data
        SQLiteDatabase SQ = dop.getWritableDatabase();
        //Next creating object of Contentvalue in inserting of the data
        ContentValues cv = new ContentValues();
        //Add each value of columns into the contentvalues object
        cv.put(TableInfo.USER_NAME, name);
        cv.put(TableInfo.USER_PASS, pass);
        //inserting the data into the table using that sqlite database obnject
        long k = SQ.insert(TableInfo.TABLE_NAME, null, cv);
        Log.d("Database Operations", "One row inserted");
    }

    //User defined method to retrieve the data
    public Cursor getInformation(DatabaseOperations dop) {
        //create the object of sqlite database
        SQLiteDatabase SQ = dop.getReadableDatabase();
        String[] columns = {TableInfo.USER_NAME, TableInfo.USER_PASS};
        //Get the data inform of an object of a data class
        Cursor CR = SQ.query(TableInfo.TABLE_NAME, columns, null, null, null, null, null);
        return CR;
    }

    public Cursor getUserPass(DatabaseOperations DOP, String user) {
        SQLiteDatabase SQ = DOP.getReadableDatabase();

        String selection = TableInfo.USER_NAME + " LIKE ?";
        String columns[] = {TableInfo.USER_PASS};
        String args[] = {user};
        Cursor CR = SQ.query(TableInfo.TABLE_NAME, columns, selection, args, null, null, null);
        return CR;

    }

    public void deleteUser(DatabaseOperations DOP, String user, String pass) {
        String selection = TableInfo.USER_NAME + " LIKE ? AND " + TableInfo.USER_PASS + " LIKE ?";
       //String columns[] = {TableInfo.USER_PASS};
        //The column was commented because we are not making any selection like the previous one but we are deleting
        String args[] = {user, pass};
        SQLiteDatabase SQ = DOP.getWritableDatabase();
        SQ.delete(TableInfo.TABLE_NAME,selection,args);


    }

}

