package com.tobi.FivePointerOld;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class EightCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix,fiveseven, fiveeight;
    private TextView nameofText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eight_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        fiveone = (EditText) findViewById(R.id.fivePointeightFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointeightSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointeightThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointeightFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointeightFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointeightSixthcourse);
        fiveseven = (EditText) findViewById(R.id.fivePointeightSeventhcourse);
        fiveeight = (EditText) findViewById(R.id.fivePointeightEightcourse);
        nameofText = (TextView) findViewById(R.id.fiveoldeightnameOfCoursesText);


        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        fiveeight.setTypeface(normal);
        nameofText.setTypeface(bold);



        cclickme = (Button)findViewById(R.id.fiveoldeightcoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent intent2 = new Intent(EightCoursesActivity.this, NextEightCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                intent2.putExtra("8", fiveeight.getText().toString());
                startActivity(intent2);



            }
        });


    }

}







