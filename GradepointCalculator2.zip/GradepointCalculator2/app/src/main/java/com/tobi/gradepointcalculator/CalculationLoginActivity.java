package com.tobi.gradepointcalculator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import com.tobi.Chooser.ChooserCoursesActivity;
import com.tobi.FivePointerNew.FiveBCoursesActivity;
import com.tobi.FivePointerOld.EightCoursesActivity;
import com.tobi.FivePointerOld.ElevenCoursesActivity;
import com.tobi.FivePointerOld.FiveCoursesActivity;
import com.tobi.FivePointerOld.NineCoursesActivity;
import com.tobi.FivePointerOld.SevenCoursesActivity;
import com.tobi.FivePointerOld.SixCoursesActivity;
import com.tobi.FivePointerOld.TenCoursesActivity;
import com.tobi.FivePointerOld.ThirteenCoursesActivity;
import com.tobi.FivePointerOld.TwelveCoursesActivity;

public class CalculationLoginActivity extends AppCompatActivity {
    TextView textView5, textViewSix, textView7, textView8, textView9, textView10, textView11, textView12, textView13, typedText,ok;
    public static String INTENT_VALUE = "value_check";
   String getold;
    String getnew;
    String getpoly;
    String getibadan;
    String getamerica;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculation_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textView5 = (TextView)findViewById(R.id.NumberFive);
        textViewSix = (TextView)findViewById(R.id.NumberSix);
        textView7 = (TextView)findViewById(R.id.NumberSeven);
        textView8 = (TextView)findViewById(R.id.NumberEight);
        textView9 = (TextView)findViewById(R.id.NumberNine);
        textView10 = (TextView)findViewById(R.id.NumberTen);
        textView11 = (TextView)findViewById(R.id.NumberEleven);
        textView12 = (TextView)findViewById(R.id.NumberTwelve);
        textView13 = (TextView)findViewById(R.id.Number13);
        typedText = (TextView)findViewById(R.id.typedText);
        ok = (TextView)findViewById(R.id.ok);

        onClickingTheNumber(this);
        onContinueClicked();

    }

    public void onClickingTheNumber(final Context context) {

        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("5");
            }
        });
        textViewSix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("6");
            }
        });
        textView7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("7");
            }
        });
        textView8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("8");
            }
        });
        textView9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("9");
            }
        });
        textView10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("10");
            }
        });
        textView11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("11");

            }
        });
        textView12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("12");
            }
        });
        textView13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                typedText.startAnimation(AnimationUtils.loadAnimation(context, android.R.anim.fade_in));
                typedText.setText("13");
            }
        });
    }

    public void onContinueClicked() {

        ok.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {


//                Bundle extras = getIntent().getExtras();
//                Bundle extras2 = getIntent().getExtras();



                try {
                    if (typedText.getText().equals("Toast")) {
                        Toast.makeText(getBaseContext(), "Type your courses number", Toast.LENGTH_LONG).show();

                    }



                         else if(getIntent().getStringExtra(INTENT_VALUE).equals("Fiveold")) {

                            if (typedText.getText().equals("5")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, FiveCoursesActivity.class);
                                startActivity(intent);
                            } else if (typedText.getText().equals("6")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, SixCoursesActivity.class);
                                startActivity(intent);
                                //Toast.makeText(getBaseContext(), "You must type five to proceed",Toast.LENGTH_SHORT).show();
                            } else if (typedText.getText().equals("7")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, SevenCoursesActivity.class);
                                startActivity(intent);
                            } else if (typedText.getText().equals("8")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, EightCoursesActivity.class);
                                startActivity(intent);
                                //   Toast.makeText(getBaseContext(), "You must type five to proceed",Toast.LENGTH_SHORT).show();

                            } else if (typedText.getText().equals("9")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, NineCoursesActivity.class);
                                startActivity(intent);
                            } else if (typedText.getText().equals("10")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, TenCoursesActivity.class);
                                startActivity(intent);
                            } else if (typedText.getText().equals("!1")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, ElevenCoursesActivity.class);
                                startActivity(intent);
                            } else if (typedText.getText().equals("12")) {
                                Intent intent = new Intent(CalculationLoginActivity.this, TwelveCoursesActivity.class);
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(CalculationLoginActivity.this, ThirteenCoursesActivity.class);
                                startActivity(intent);
                            }


                        }



                    
                }
            catch (Exception e) {
                Log.e("ActivityError", "IT DIDNT WORK BECAUSE " + e.getMessage());
                Toast.makeText(getBaseContext(), "All values must be filled", Toast.LENGTH_LONG).show();

            }
            }
        });

    }

}
