package com.tobi.Chooser;

/**
 * Created by Aloine Inc on 11/18/2015.
 */
public class Datas {
 private int imagel;
    private String namel;
    private String descriptionl;

    public Datas(int imagel, String namel, String descriptionl) {
        this.imagel = imagel;
        this.namel = namel;
        this.descriptionl = descriptionl;
    }

    public int getImagel() {
        return imagel;
    }

    public String getNamel() {
        return namel;
    }

    public String getDescriptionl() {
        return descriptionl;
    }
}
