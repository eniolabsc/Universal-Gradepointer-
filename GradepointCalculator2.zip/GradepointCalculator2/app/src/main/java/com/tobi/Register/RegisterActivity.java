package com.tobi.Register;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.tobi.gradepointcalculator.DatabaseOperations;
import com.tobi.gradepointcalculator.NavigationDrawerFragment;
import com.tobi.gradepointcalculator.R;

public class RegisterActivity extends AppCompatActivity {
    public static String INTENT_VALUE ="value_check";
    public String gotten_value;

    EditText USER_NAME, USER_PASS, CON_PASS;
    String user_name, user_pass, con_pass;
    Button REG;
    Context ctx = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        NavigationDrawerFragment drawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), toolbar);



//        gotten_value = getIntent().getStringExtra(INTENT_VALUE).toString();

        USER_NAME = (EditText)findViewById(R.id.register_username);
        USER_PASS = (EditText)findViewById(R.id.register_password);
        CON_PASS = (EditText)findViewById(R.id.confirm_register_password);
        REG = (Button)findViewById(R.id.register_button);
        REG.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get the data from the editext field
                user_name = USER_NAME.getText().toString();
                user_pass = USER_PASS.getText().toString();
                con_pass = CON_PASS.getText().toString();

                if(!(user_pass.equals(con_pass)) || user_name.isEmpty() || user_pass.isEmpty() || con_pass.isEmpty())
                {
                    Toast.makeText(getBaseContext(),"All necessary register details must be filled Appropriately",Toast.LENGTH_LONG).show();
                    USER_NAME.setText("");
                    USER_PASS.setText("");
                    CON_PASS.setText("");
                }
                else
                {//To enter the data into the database, you will need an object of context
                    DatabaseOperations DB = new DatabaseOperations(ctx);
                    DB.putInformation(DB,user_name,user_pass);
                    Toast.makeText(getBaseContext(),"Registration is successful",Toast.LENGTH_LONG).show();
                    finish();

                }
            }
        });




}

}