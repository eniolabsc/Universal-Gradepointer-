package com.tobi.delete;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.tobi.gradepointcalculator.DatabaseOperations;
import com.tobi.gradepointcalculator.R;

import static android.view.View.*;

public class DeleteActivity extends AppCompatActivity {
    String USERNAME;
    Button Del;
    EditText PASS;
    String Pass;
    DatabaseOperations DOP;
    Context CTX= this;
        Bundle bn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Del = (Button)findViewById(R.id.delete_button);
        PASS = (EditText)findViewById(R.id.delete_edittext);
        Del.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Pass = PASS.getText().toString();
                DOP = new DatabaseOperations(CTX);
                Cursor CR = DOP.getInformation(DOP);
                //There is a problem with this line of code getUserPass was used but i havent used intent from the beginning
                CR.moveToFirst();
                boolean loginstatus = false;
                do
                {
                    if (Pass.equals(CR.getString(0))) {
                        loginstatus = true;
                    }

                }while(CR.moveToNext());
                if (loginstatus) {
                    //delete user here
                    DOP.deleteUser(DOP,USERNAME,Pass);
                    Toast.makeText(getBaseContext(),"User removed successfully",Toast.LENGTH_LONG).show();

                }
                else
                {
                    Toast.makeText(getBaseContext(),"Invalid User \n Try again",Toast.LENGTH_LONG).show();
                }

            }
        });
    }

}
