package com.tobi.login;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tobi.Chooser.ChooserCoursesActivity;
import com.tobi.gradepointcalculator.DatabaseOperations;
import com.tobi.gradepointcalculator.R;


public class LoginActivity extends AppCompatActivity {
    Button Login;
    EditText USERNAME, USERPASS;
    String username, userpass;
    Context CTX = this;
  //  int status = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Login = (Button) findViewById(R.id.loginButton);
        USERNAME = (EditText) findViewById(R.id.loginUsername);
        USERPASS = (EditText) findViewById(R.id.loginPassword);
        Login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                    Toast.makeText(getBaseContext(), "Please wait...", Toast.LENGTH_LONG).show();
                    username = USERNAME.getText().toString();
                    userpass = USERPASS.getText().toString();
                    DatabaseOperations DOP = new DatabaseOperations(CTX);
                    Cursor CR = DOP.getInformation(DOP);

                    //WE need an object cursor class to receive data from the method
                    CR.moveToFirst();
                    boolean loginstatus = false;
                    String NAME = "";
                    do {
                        if (username.equals(CR.getString(0)) && userpass.equals(CR.getString(1))) {
                            loginstatus = true;
                            NAME = CR.getString(0);
                        }

                    } while (CR.moveToNext());
                    if (loginstatus) {
                       // Toast.makeText(getBaseContext(), "Login Success \n Welcome " + NAME, Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(LoginActivity.this, ChooserCoursesActivity.class);
//                      intent.putExtra("whatkind", "fiveold");
//                        intent.putExtra("whatkind", "fivenew");
//                        intent.putExtra("whatkind", "poly");
//                        intent.putExtra("whatkind", "ibadan");
//                        intent.putExtra("whatkind", "america");

                        startActivity(intent);
                        overridePendingTransition( R.anim.abc_slide_in_bottom, android.R.anim.fade_out);
                    } else {
                        Toast.makeText(getBaseContext(), "Login Failed", Toast.LENGTH_LONG).show();
                    }

            }
        });


    }
}