package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;


public class TwelveBCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix, fiveseven, fiveeight, fivenine, fiveten, fiveeleven, fivetwelve;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twelveb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fiveone = (EditText) findViewById(R.id.fivePointbTwelveFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointbTwelveSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointbTwelveThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointbTwelveFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointbTwelveFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointbTwelveSixthcourse);
        fiveseven = (EditText) findViewById(R.id.fivePointbTwelveSeventhcourse);
        fiveeight = (EditText) findViewById(R.id.fivePointbTwelveEightcourse);
        fivenine = (EditText) findViewById(R.id.fivePointbTwelveNinthcourse);
        fiveten = (EditText) findViewById(R.id.fivePointbTwelveTencourse);
        fiveeleven = (EditText) findViewById(R.id.fivePointbTwelveElevencourse);
        fivetwelve = (EditText) findViewById(R.id.fivePointbTwelveTwelvecourse);

        nameofText = (TextView) findViewById(R.id.fivenewtwelvenameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        fiveeight.setTypeface(normal);
        fivenine.setTypeface(normal);
        fiveten.setTypeface(normal);
        fiveeleven.setTypeface(normal);
        fivetwelve.setTypeface(normal);

//        nameofText.setTypeface(bold);

        cclickme = (Button) findViewById(R.id.Fivenewtwelvecoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(TwelveBCoursesActivity.this, NextTwelveBCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                intent2.putExtra("8", fiveeight.getText().toString());
                intent2.putExtra("9", fivenine.getText().toString());
                intent2.putExtra("10", fiveten.getText().toString());
                intent2.putExtra("11", fiveeleven.getText().toString());
                intent2.putExtra("12", fivetwelve.getText().toString());


                startActivity(intent2);


            }
        });


    }

}
