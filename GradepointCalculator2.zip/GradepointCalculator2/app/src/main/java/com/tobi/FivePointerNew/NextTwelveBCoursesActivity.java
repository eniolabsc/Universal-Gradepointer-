package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.tobi.gradepointcalculator.R;


public class NextTwelveBCoursesActivity extends AppCompatActivity {
    private Button button;
    TextView got1, got2, got3, got4, got5, got6, got7, got8, got9, got10, got11, got12;
    EditText unit1, score1, unit2, score2, unit3, score3, unit4, score4, unit5, score5, unit6, score6, unit7, score7,
            unit8, score8, unit9, score9, unit10, score10, unit11, score11, unit12, score12;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_twelveb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        got1 = (TextView) findViewById(R.id.next_bTwelvefive1);
        got2 = (TextView) findViewById(R.id.next_bTwelvefive2);
        got3 = (TextView) findViewById(R.id.next_bTwelvefive3);
        got4 = (TextView) findViewById(R.id.next_bTwelvefive4);
        got5 = (TextView) findViewById(R.id.next_bTwelvefive5);
        got6 = (TextView) findViewById(R.id.next_bTwelvefive6);
        got7 = (TextView) findViewById(R.id.next_bTwelvefive7);
        got8 = (TextView) findViewById(R.id.next_bTwelvefive8);
        got9 = (TextView) findViewById(R.id.next_bTwelvefive9);
        got10 = (TextView) findViewById(R.id.next_bTwelvefive10);
        got11 = (TextView) findViewById(R.id.next_bTwelvefive11);
        got12 = (TextView) findViewById(R.id.next_bTwelvefive12);

        unit1 = (EditText) findViewById(R.id.next_bTwelvefiveunit1);
        score1 = (EditText) findViewById(R.id.next_bTwelvefivescore1);
        unit2 = (EditText) findViewById(R.id.next_bTwelvefiveunit2);
        score2 = (EditText) findViewById(R.id.next_bTwelvefivescore2);
        unit3 = (EditText) findViewById(R.id.next_bTwelvefiveunit3);
        score3 = (EditText) findViewById(R.id.next_bTwelvefivescore3);
        unit4 = (EditText) findViewById(R.id.next_bTwelvefiveunit4);
        score4 = (EditText) findViewById(R.id.next_bTwelvefivescore4);
        unit5 = (EditText) findViewById(R.id.next_bTwelvefiveunit5);
        score5 = (EditText) findViewById(R.id.next_bTwelvefivescore5);
        unit6 = (EditText) findViewById(R.id.next_bTwelvefiveunit6);
        score6 = (EditText) findViewById(R.id.next_bTwelvefivescore6);
        unit7 = (EditText) findViewById(R.id.next_bTwelvefiveunit7);
        score7 = (EditText) findViewById(R.id.next_bTwelvefivescore7);
        unit8 = (EditText) findViewById(R.id.next_bTwelvefiveunit8);
        score8 = (EditText) findViewById(R.id.next_bTwelvefivescore8);

        unit9 = (EditText) findViewById(R.id.next_bTwelvefiveunit9);
        score9 = (EditText) findViewById(R.id.next_bTwelvefivescore9);

        unit10 = (EditText) findViewById(R.id.next_bTwelvefiveunit10);
        score10 = (EditText) findViewById(R.id.next_bTwelvefivescore10);

        unit11 = (EditText) findViewById(R.id.next_bTwelvefiveunit11);
        score11 = (EditText) findViewById(R.id.next_bTwelvefivescore11);

        unit12 = (EditText) findViewById(R.id.next_bTwelvefiveunit12);
        score12 = (EditText) findViewById(R.id.next_bTwelvefivescore12);


        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");

        got1.setTypeface(bold);
        got2.setTypeface(bold);
        got3.setTypeface(bold);
        got4.setTypeface(bold);
        got5.setTypeface(bold);
        got6.setTypeface(bold);
        got7.setTypeface(bold);
        got8.setTypeface(bold);
        got9.setTypeface(bold);
        got10.setTypeface(bold);
        got11.setTypeface(bold);
        got12.setTypeface(bold);


        score1.setTypeface(normal);
        score2.setTypeface(normal);
        score3.setTypeface(normal);
        score4.setTypeface(normal);
        score5.setTypeface(normal);
        score6.setTypeface(normal);
        score7.setTypeface(normal);
        score8.setTypeface(normal);
        score9.setTypeface(normal);
        score10.setTypeface(normal);
        score11.setTypeface(normal);
        score12.setTypeface(normal);

        unit1.setTypeface(normal);
        unit2.setTypeface(normal);
        unit3.setTypeface(normal);
        unit4.setTypeface(normal);
        unit5.setTypeface(normal);
        unit6.setTypeface(normal);
        unit7.setTypeface(normal);
        unit8.setTypeface(normal);
        unit9.setTypeface(normal);
        unit10.setTypeface(normal);
        unit11.setTypeface(normal);
        unit12.setTypeface(normal);






        Intent intent = getIntent();
        String one = intent.getStringExtra("1");
        String two = intent.getStringExtra("2");
        String three = intent.getStringExtra("3");
        String four = intent.getStringExtra("4");
        String five = intent.getStringExtra("5");
        String six = intent.getStringExtra("6");
        String seven = intent.getStringExtra("7");
        String eight = intent.getStringExtra("8");
        String nine = intent.getStringExtra("9");
        String ten = intent.getStringExtra("10");
        String eleven = intent.getStringExtra("11");
        String twelve = intent.getStringExtra("12");



        got1.setText(one);
        got2.setText(two);
        got3.setText(three);
        got4.setText(four);
        got5.setText(five);
        got6.setText(six);
        got7.setText(seven);
        got8.setText(eight);
        got9.setText(nine);
        got10.setText(ten);
        got11.setText(eleven);
        got12.setText(twelve);


        button = (Button) findViewById(R.id.fivepointboldfivenextactivityButton3);

        button.setOnClickListener(new View.OnClickListener() {
            String un1, sc1, un2, sc2, un3, sc3, un4, sc4, un5, sc5, un6, sc6, un7, sc7, un8, sc8, un9, sc9, un10, sc10, un11, sc11, un12, sc12;
            int u1, s1, u2, s2, u3, s3, u4, s4, u5, s5, u6, s6, u7, s7, u8, s8, u9, s9, u00, s00, u01, s01, u02, s02;
            int s11, s12, s13, s14, s15, s16, s17, s18, s19, s20, s21, s22;
            int total;
            double totald, sumofunit, gp;
            private TextView tv = (TextView) findViewById(R.id.resultoffivePointfive2);

            @Override
            public void onClick(View v) {
                try {
                    un1 = unit1.getText().toString();
                    sc1 = score1.getText().toString();
                    un2 = unit2.getText().toString();
                    sc2 = score2.getText().toString();
                    un3 = unit3.getText().toString();
                    sc3 = score3.getText().toString();
                    un4 = unit4.getText().toString();
                    sc4 = score4.getText().toString();
                    un5 = unit5.getText().toString();
                    sc5 = score5.getText().toString();
                    un6 = unit6.getText().toString();
                    sc6 = score6.getText().toString();
                    un7 = unit7.getText().toString();
                    sc7 = score7.getText().toString();
                    un8 = unit8.getText().toString();
                    sc8 = score8.getText().toString();
                    un9 = unit9.getText().toString();
                    sc9 = score9.getText().toString();
                    un10 = unit10.getText().toString();
                    sc10 = score10.getText().toString();
                    un11 = unit11.getText().toString();
                    sc11 = score11.getText().toString();
                    un12 = unit12.getText().toString();
                    sc12 = score12.getText().toString();


                    u1 = Integer.parseInt(un1);
                    u2 = Integer.parseInt(un2);
                    u3 = Integer.parseInt(un3);
                    u4 = Integer.parseInt(un4);
                    u5 = Integer.parseInt(un5);
                    u6 = Integer.parseInt(un6);
                    u7 = Integer.parseInt(un7);
                    u8 = Integer.parseInt(un8);
                    u9 = Integer.parseInt(un9);
                    u00 = Integer.parseInt(un10);
                    u01 = Integer.parseInt(un11);
                    u02 = Integer.parseInt(un12);


                    final int[] unit = {u1
                            , u2, u3, u4, u5, u6, u7, u8, u9, u00, u01, u02};


                    s1 = Integer.parseInt(sc1);
                    s2 = Integer.parseInt(sc2);
                    s3 = Integer.parseInt(sc3);
                    s4 = Integer.parseInt(sc4);
                    s5 = Integer.parseInt(sc5);
                    s6 = Integer.parseInt(sc6);
                    s7 = Integer.parseInt(sc7);
                    s8 = Integer.parseInt(sc8);
                    s9 = Integer.parseInt(sc9);
                    s00 = Integer.parseInt(sc10);
                    s01 = Integer.parseInt(sc11);
                    s02 = Integer.parseInt(sc12);


                    sumofunit = Double.parseDouble(un1)
                            + Double.parseDouble(un2) + Double.parseDouble(un3) +
                            Double.parseDouble(un4) + Double.parseDouble(un5) + Double.parseDouble(un6)
                            + Double.parseDouble(un7) + Double.parseDouble(un8) + Double.parseDouble(un9) + Double.parseDouble(un10)
                            + Double.parseDouble(un11) + Double.parseDouble(un12);

                    s11 = unit[0] * checkScore(s1);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s11);
                    s12 = unit[1] * checkScore(s2);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s12);

                    s13 = unit[2] * checkScore(s3);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s13);

                    s14 = unit[3] * checkScore(s4);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s14);

                    s15 = unit[4] * checkScore(s5);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s15);

                    s16 = unit[5] * checkScore(s6);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s16);
                    s17 = unit[6] * checkScore(s7);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s17);
                    s18 = unit[7] * checkScore(s8);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s18);
                    s19 = unit[8] * checkScore(s9);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s19);
                    s20 = unit[9] * checkScore(s00);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s20);
                    s21 = unit[10] * checkScore(s01);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s21);
                    s22 = unit[11] * checkScore(s02);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s22);


                    total = s11 + s12 + s13 + s14 + s15 + s16 + s17 + s18 + s19 + s20 + s21 + s22;
                    totald = total;
                    gp = totald / sumofunit;

                    tv.setText("Your GradePoint is " + gp);


                } catch (Exception e) {
                    Log.e("MULT ERROR", "IT DIDNT WORK BECASE " + e.getMessage());
                    Toast.makeText(getBaseContext(), "All values must be filled", Toast.LENGTH_LONG).show();


                }


            }
        });


    }

    public static int checkScore(int score) {

        int points = 0;
       /* for (int k = 0; k < score.length; k++) {*/
        if (score <= 100 && score >= 70) {
            points = 5;
        } else if (score <= 69 && score >= 60) {
            points = 4;
        } else if (score <= 59 && score >= 50) {
            points = 3;
        } else if (score <= 49 && score >= 45) {
            points = 2;
        } else {
            points = 0;
        }


        return points;


    }


}
