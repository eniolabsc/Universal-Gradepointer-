package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;


public class ThirteenBCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix,fiveseven, fiveeight
            ,fivenine,fiveten,fiveeleven,fivetwelve,fivethirteen;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirteenb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        fiveone = (EditText) findViewById(R.id.fivePointbThirteenFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointbThirteenSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointbThirteenThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointbThirteenFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointbThirteenFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointbThirteenSixthcourse);
        fiveseven = (EditText) findViewById(R.id.fivePointbThirteenSeventhcourse);
        fiveeight = (EditText) findViewById(R.id.fivePointbThirteenEightcourse);
        fivenine = (EditText) findViewById(R.id.fivePointbThirteenNinthcourse);
        fiveten =(EditText) findViewById(R.id.fivePointbThirteenTencourse);
        fiveeleven = (EditText) findViewById(R.id.fivePointbThirteenElevencourse);
        fivetwelve = (EditText) findViewById(R.id.fivePointbThirteenTwelvecourse);
        fivethirteen = (EditText) findViewById(R.id.fivePointbThirteenThirteenthcourse);





        nameofText = (TextView) findViewById(R.id.fivenewthirteennameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        fiveseven.setTypeface(normal);
        fiveeight.setTypeface(normal);
        fivenine.setTypeface(normal);
        fiveten.setTypeface(normal);
        fiveeleven.setTypeface(normal);
        fivetwelve.setTypeface(normal);
        fivethirteen.setTypeface(normal);
        nameofText.setTypeface(bold);

        cclickme = (Button)findViewById(R.id.Fivenewthirteencoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent2 = new Intent(ThirteenBCoursesActivity.this, NextThirteenBCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                intent2.putExtra("7", fiveseven.getText().toString());
                intent2.putExtra("8", fiveeight.getText().toString());
                intent2.putExtra("9", fivenine.getText().toString());
                intent2.putExtra("10", fiveten.getText().toString());
                intent2.putExtra("11", fiveeleven.getText().toString());
                intent2.putExtra("12", fivetwelve.getText().toString());
                intent2.putExtra("13", fivethirteen.getText().toString());

                startActivity(intent2);


            }
        });


    }


}
