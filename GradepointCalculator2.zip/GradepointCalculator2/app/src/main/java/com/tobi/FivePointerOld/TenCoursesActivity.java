package com.tobi.FivePointerOld;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class TenCoursesActivity extends AppCompatActivity {
    Button clicked;
    EditText tenone, tentwo, tenthree, tenfour, tenfive, tensix, tenseven, teneight, tennine, tenten;
    private TextView nameofText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ten_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tenone = (EditText) findViewById(R.id.fivePointtenFirstCourse);
        tentwo = (EditText) findViewById(R.id.fivePointtenSecondCourse);
        tenthree = (EditText) findViewById(R.id.fivePointtenThirdCourse);
        tenfour = (EditText) findViewById(R.id.fivePointtenFourthCourse);
        tenfive = (EditText) findViewById(R.id.fivePointtenFifthCourse);
        tensix = (EditText) findViewById(R.id.fivePointtenSixthCourse);
        tenseven = (EditText) findViewById(R.id.fivePointtenSeventhCourse);
        teneight = (EditText) findViewById(R.id.fivePointtenEightCourse);
        tennine = (EditText) findViewById(R.id.fivePointtenNinthCourse);
        tenten = (EditText) findViewById(R.id.fivePointtenTenCourse);

        nameofText = (TextView) findViewById(R.id.fiveoldtennameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        tenone.setTypeface(normal);
        tentwo.setTypeface(normal);
        tenthree.setTypeface(normal);
        tenfour.setTypeface(normal);
        tenfive.setTypeface(normal);
        tensix.setTypeface(normal);
        tenseven.setTypeface(normal);
        teneight.setTypeface(normal);
        tennine.setTypeface(normal);
        tenten.setTypeface(normal);
        nameofText.setTypeface(bold);

        clicked = (Button) findViewById(R.id.Fiveoldtencoursesbutton);
        clicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TenCoursesActivity.this, NextTenCoursesActivity.class);
                intent.putExtra("1", tenone.getText().toString());
                intent.putExtra("2", tentwo.getText().toString());
                intent.putExtra("3", tenthree.getText().toString());
                intent.putExtra("4", tenfour.getText().toString());
                intent.putExtra("5", tenfive.getText().toString());
                intent.putExtra("6", tensix.getText().toString());
                intent.putExtra("7", tenseven.getText().toString());
                intent.putExtra("8", teneight.getText().toString());
                intent.putExtra("9", tennine.getText().toString());
                intent.putExtra("10", tenten.getText().toString());
                startActivity(intent);

            }
        });







    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
