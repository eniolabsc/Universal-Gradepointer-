package com.tobi.FivePointerOld;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class SixCoursesActivity extends AppCompatActivity {
    private Button cclickme;
    private EditText fiveone, fivetwo, fivethree, fivefour, fivefive, fivesix;
    private TextView nameofText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_six_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fiveone = (EditText) findViewById(R.id.fivePointsixFirstCourse);
        fivetwo = (EditText) findViewById(R.id.fivePointsixSecondCourse);
        fivethree = (EditText) findViewById(R.id.fivePointsixThirdCourse);
        fivefour = (EditText) findViewById(R.id.fivePointsixFourthCourse);
        fivefive = (EditText) findViewById(R.id.fivePointsixFifthCourse);
        fivesix = (EditText) findViewById(R.id.fivePointsixSixthcourse);

        nameofText = (TextView) findViewById(R.id.fiveoldsixnameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);
        fivesix.setTypeface(normal);
        nameofText.setTypeface(bold);


        cclickme = (Button)findViewById(R.id.Fiveoldsixcoursesbutton);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent2 = new Intent(SixCoursesActivity.this, NextSixCoursesActivity.class);

                intent2.putExtra("1", fiveone.getText().toString());
                intent2.putExtra("2", fivetwo.getText().toString());
                intent2.putExtra("3", fivethree.getText().toString());
                intent2.putExtra("4", fivefour.getText().toString());
                intent2.putExtra("5", fivefive.getText().toString());
                intent2.putExtra("6", fivesix.getText().toString());
                startActivity(intent2);






            }
        });


    }

}


