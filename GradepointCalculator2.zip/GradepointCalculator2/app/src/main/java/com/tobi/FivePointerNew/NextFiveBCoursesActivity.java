package com.tobi.FivePointerNew;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.tobi.gradepointcalculator.R;;


public class NextFiveBCoursesActivity extends AppCompatActivity {
    private Button clickme;
    TextView got1, got2, got3, got4, got5;
    EditText unit1, score1, unit2, score2, unit3, score3, unit4, score4, unit5, score5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_fiveb_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        got1 = (TextView) findViewById(R.id.next_bfivefive1);
        got2 = (TextView) findViewById(R.id.next_bfivefive2);
        got3 = (TextView) findViewById(R.id.next_bfivefive3);
        got4 = (TextView) findViewById(R.id.next_bfivefive4);
        got5 = (TextView) findViewById(R.id.next_bfivefive5);

        unit1 = (EditText) findViewById(R.id.next_bfivefiveunit1);
        score1 = (EditText) findViewById(R.id.next_bfivefivescore1);
        unit2 = (EditText) findViewById(R.id.next_bfivefiveunit2);
        score2 = (EditText) findViewById(R.id.next_bfivefivescore2);
        unit3 = (EditText) findViewById(R.id.next_bfivefiveunit3);
        score3 = (EditText) findViewById(R.id.next_bfivefivescore3);
        unit4 = (EditText) findViewById(R.id.next_bfivefiveunit4);
        score4 = (EditText) findViewById(R.id.next_bfivefivescore4);
        unit5 = (EditText) findViewById(R.id.next_bfivefiveunit5);
        score5 = (EditText) findViewById(R.id.next_bfivefivescore5);


        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");

        got1.setTypeface(bold);
        got2.setTypeface(bold);
        got3.setTypeface(bold);
        got4.setTypeface(bold);
        got5.setTypeface(bold);


        score1.setTypeface(normal);
        score2.setTypeface(normal);
        score3.setTypeface(normal);
        score4.setTypeface(normal);
        score5.setTypeface(normal);


        unit1.setTypeface(normal);
        unit2.setTypeface(normal);
        unit3.setTypeface(normal);
        unit4.setTypeface(normal);
        unit5.setTypeface(normal);


        Intent intent = getIntent();
        String one = intent.getStringExtra("1");
        String two = intent.getStringExtra("2");
        String three = intent.getStringExtra("3");
        String four = intent.getStringExtra("4");
        String five = intent.getStringExtra("5");


        got1.setText(one);
        got2.setText(two);
        got3.setText(three);
        got4.setText(four);
        got5.setText(five);


        Button button = (Button) findViewById(R.id.fivepointboldfivenextactivityButton);

        button.setOnClickListener(new View.OnClickListener() {
            String un1, sc1, un2, sc2, un3, sc3, un4, sc4, un5, sc5;
            int u1, s1, u2, s2, u3, s3, u4, s4, u5, s5;
            int s11, s12, s13, s14, s15;
            int total;
            double totald, sumofunit, gp;
            private TextView tv = (TextView) findViewById(R.id.resultoffivePointfive);

            @Override
            public void onClick(View v) {
                try {
                    un1 = unit1.getText().toString();
                    sc1 = score1.getText().toString();
                    un2 = unit2.getText().toString();
                    sc2 = score2.getText().toString();
                    un3 = unit3.getText().toString();
                    sc3 = score3.getText().toString();
                    un4 = unit4.getText().toString();
                    sc4 = score4.getText().toString();
                    un5 = unit5.getText().toString();
                    sc5 = score5.getText().toString();

                    u1 = Integer.parseInt(un1);
                    u2 = Integer.parseInt(un2);
                    u3 = Integer.parseInt(un3);
                    u4 = Integer.parseInt(un4);
                    u5 = Integer.parseInt(un5);

                    final int[] unit = {u1
                            , u2, u3, u4, u5,};


                    s1 = Integer.parseInt(sc1);
                    s2 = Integer.parseInt(sc2);
                    s3 = Integer.parseInt(sc3);
                    s4 = Integer.parseInt(sc4);
                    s5 = Integer.parseInt(sc5);


                    sumofunit = Double.parseDouble(un1)
                            + Double.parseDouble(un2) + Double.parseDouble(un3) +
                            Double.parseDouble(un4) + Double.parseDouble(un5);

                    s11 = unit[0] * checkScore(s1);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s11);
                    s12 = unit[1] * checkScore(s2);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s12);

                    s13 = unit[2] * checkScore(s3);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s13);

                    s14 = unit[3] * checkScore(s4);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s14);

                    s15 = unit[4] * checkScore(s5);
                    Log.d("LOG MULT", "IT MULTIPLIED " + s15);

                    total = s11 + s12 + s13 + s14 + s15;
                    totald = total;
                    gp = totald / sumofunit;

                    tv.setText("Your GradePoint is " + gp);


                } catch (Exception e) {
                    Log.e("MULT ERROR", "IT DIDNT WORK BECASE " + e.getMessage());
                    Toast.makeText(getBaseContext(), "All values must be filled", Toast.LENGTH_LONG).show();


                }


            }
        });


    }

    public static int checkScore(int score) {

        int points = 0;
       /* for (int k = 0; k < score.length; k++) {*/
        if (score <= 100 && score >= 70) {
            points = 5;
        } else if (score <= 69 && score >= 60) {
            points = 4;
        } else if (score <= 59 && score >= 50) {
            points = 3;
        } else if (score <= 49 && score >= 45) {
            points = 2;
            ;
        } else {
            points = 0;
        }


        return points;


    }
}
