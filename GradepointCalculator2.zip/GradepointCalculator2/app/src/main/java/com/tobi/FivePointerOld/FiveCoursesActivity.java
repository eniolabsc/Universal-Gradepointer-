package com.tobi.FivePointerOld;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tobi.gradepointcalculator.R;

public class FiveCoursesActivity extends AppCompatActivity {
   private  Button cclickme;
    private EditText  fiveone, fivetwo, fivethree, fivefour, fivefive;
    private TextView nameofText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_five_courses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        fiveone = (EditText)findViewById(R.id.fivePointfiveFirstCourse);
        fivetwo = (EditText)findViewById(R.id.fivePointfiveSecondCourse);
        fivethree = (EditText)findViewById(R.id.fivePointfiveThirdCourse);
        fivefour = (EditText)findViewById(R.id.fivePointfiveFourthCourse);
        fivefive = (EditText)findViewById(R.id.fivePointfiveFifthCourse);



        nameofText = (TextView) findViewById(R.id.fiveoldfivenameOfCoursesText);

        Typeface bold = Typeface.createFromAsset(getAssets(), "fonts/bold.otf");
        Typeface light = Typeface.createFromAsset(getAssets(), "fonts/light.otf");
        Typeface normal = Typeface.createFromAsset(getAssets(), "fonts/normal.otf");
        fiveone.setTypeface(normal);
        fivetwo.setTypeface(normal);
        fivethree.setTypeface(normal);
        fivefour.setTypeface(normal);
        fivefive.setTypeface(normal);



        cclickme = (Button)findViewById(R.id.Fiveoldfivecoursesbuttonb);
        cclickme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(FiveCoursesActivity.this,NextFiveCoursesActivity.class);

                intent.putExtra("1",fiveone.getText().toString());
                intent.putExtra("2",fivetwo.getText().toString());
                intent.putExtra("3",fivethree.getText().toString());
                intent.putExtra("4",fivefour.getText().toString());
                intent.putExtra("5", fivefive.getText().toString());
                startActivity(intent);










            }
        });


    }

}
