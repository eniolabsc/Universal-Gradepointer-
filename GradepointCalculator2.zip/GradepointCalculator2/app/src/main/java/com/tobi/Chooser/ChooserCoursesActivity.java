package com.tobi.Chooser;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import com.tobi.gradepointcalculator.CalculationLoginActivity;
import com.tobi.gradepointcalculator.R;

public class ChooserCoursesActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosecourses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ArrayList<Datas> datad = new ArrayList<Datas>();
        datad.add(new Datas(R.drawable.cardviewone, "FivePoint(Aboriginal)", "This was formely used in Federal Universities in Nigeria before discredited by NUC in the year 2014"));
        datad.add(new Datas(R.drawable.cardviewtwo, "FivePoint(Original)", "This is commonly used in both private and Federal Universities in Nigeria"));
        datad.add(new Datas(R.drawable.cardviewdthree, "SevenPoint", "This approach is employed in some Universities in Nigeria such as University of Ibadan "));
        datad.add(new Datas(R.drawable.cardviewfour, "FourPoint", "This is used in polytechnics and colleges of Education in Nigeria"));
        datad.add(new Datas(R.drawable.cardviewfive, "FourPoint", "This is used in Britain and the United States of America"));


        recyclerView = (RecyclerView) findViewById(R.id.recycle);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new TheAdapter(datad);
        recyclerView.setAdapter(adapter);


    }


    public class TheAdapter extends RecyclerView.Adapter<TheAdapter.TheViewHolder> {
        private ArrayList<Datas> data;

        public TheAdapter(ArrayList<Datas> data) {
            this.data = data;

        }

        @Override
        public TheViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardviewpoint, viewGroup, false);
            TheViewHolder vh = new TheViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(TheViewHolder TheViewHolder, int i) {
            final int queryString = data.get(i).getImagel();


            TheViewHolder.real.setText(data.get(i).getNamel());
            TheViewHolder.displaydown.setText(data.get(i).getDescriptionl());
            TheViewHolder.imagee.setImageResource(data.get(i).getImagel());

     /*  ProductoViewHolder.cardView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if (queryString == "Register") {
                   Intent intent = new Intent( RegisterActivity.class);
                   startActivity(intent);
               } else if
                       (queryString == "Login") {
                   Intent intent = new Intent( LoginActivity.class);
                   startActivity(intent);

               } else if
                       (queryString == "Delete User") {
                   Intent intent = new Intent(DeleteActivity.class);
                   startActivity(intent);
               }
               //Do nothing...
           }

       });


*/
            TheViewHolder.imagee.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (queryString == R.drawable.cardviewone) {
                        Intent intenting = new Intent(getApplicationContext(),CalculationLoginActivity.class);

                        int box1 = R.drawable.cardviewone;



                        intenting.putExtra("Fiveold",box1);

                        startActivity(intenting);



                    } else if (queryString == R.drawable.cardviewtwo) {
                        Intent intenting = new Intent(getApplicationContext(),CalculationLoginActivity.class);
                        int box2 = R.drawable.cardviewtwo;
                        intenting.putExtra("FiveNew", box2);
                        startActivity(intenting);

                    } else if ( queryString == R.drawable.cardviewdthree) {
                        Intent intenting = new Intent(getApplicationContext(),CalculationLoginActivity.class);
                        int box3 = R.drawable.cardviewdthree;
                        intenting.putExtra("Seven", box3);
                        startActivity(intenting);

                    } else if ( queryString == R.drawable.cardviewfour) {
                        Intent intenting = new Intent(getApplicationContext(),CalculationLoginActivity.class);
                        int box4 = R.drawable.cardviewfour;
                        intenting.putExtra("Poly", box4);
                        startActivity(intenting);

                    } else if (queryString == R.drawable.cardviewfive) {
                        Intent intenting = new Intent(getApplicationContext(),CalculationLoginActivity.class);
                        int box5 = R.drawable.cardviewfive;
                        intenting.putExtra("America",box5);
                        startActivity(intenting);
                    } else {
                        Toast.makeText(getBaseContext(),"Application Runtime", Toast.LENGTH_SHORT).show();
                    }

                }
            });


        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public class TheViewHolder extends RecyclerView.ViewHolder {
            TextView real, displaydown;
            ImageView imagee;
            CardView cardView;

            public TheViewHolder(View itemView) {
                super(itemView);

                real = (TextView) itemView.findViewById(R.id.bigText);
                displaydown = (TextView) itemView.findViewById(R.id.smalltext);
                imagee = (ImageView) itemView.findViewById(R.id.imagefortext);
                cardView = (CardView) itemView.findViewById(R.id.cardpoint);


            }
        }


    }


}